import React, { useState, useRef, useCallback } from "react";

const EMAILJS_SERVICE_ID  = "service_tl2cyih";
const EMAILJS_TEMPLATE_ID = "template_9rjh4o3";
const EMAILJS_PUBLIC_KEY  = "j2ZWRm9qh5m4LtKeR";

// ── Exact measurements from RK_106.pdf ───────────────────────────────────────
// Page: 792 × 612 (landscape A4), all values in PDF points
const PW = 792, PH = 612;
const ML = 14.6;  // left margin
// Column widths derived from exact rect positions in the sample PDF
const COL_QUALITY = 152.0;   // 14.6 → 166.6
const COL_SHAPE   = 46.9;    // 166.6 → 213.5
const COL_SIZE    = 27.5;    // each of 16 size columns (213.5→654.5 = 441/16)
const COL_TOTAL   = 26.0;    // 654.5 → 680.5  (Total)
const COL_CASE    = 27.6;    // 680.5 → 708.1  (Case)
const COL_GTOTAL  = 49.9;    // 708.1 → 758.0  (G.TOTAL)

// Row heights from sample
const RH_TITLE   = 18.0;   // SHERA HOSIERY ORDER RATIO
const RH_INFO    = 17.9;   // Ord No / Date / Party / Town / OrFrom
const RH_REMARKS = 14.2;   // REMARKS row
const RH_HEADER  = 39.8;   // Yellow header (tall for 2-line 95 XL / 100 XXL)
const RH_BODY    = 14.3;   // Each product row
const RH_GTOTAL  = 14.3;   // Grand total row

const SIZES = ["40","45/18","50/20","55/22","60/24","65/26","70/28","73/29","75/30","80/S","85/M","90/L","95 XL","100 XXL","105","110"];

// Yellow = exact (1,1,0) from pdfplumber → CSS #FFFF00
const YELLOW_CSS = "#FFFF00";
const YELLOW_PDF = [1,1,0];

// ── Product catalog — exact from Shera Hosiery official packing ratio catalog ─
const PRODUCT_CATALOG = {
  // SHERA COMATE VEST
  "COMATE WHITE":                ["RN"],
  "COMATE WHITE 2 Pcs Pack":     ["RN","RNS"],
  "COMATE PARKER":               ["RN"],
  "ENERGY":                      ["RN"],
  "ENERGY BLACK":                ["RN"],
  // SHERA COMATE FITLINE GYM VEST
  "FITLINE GYM VEST 5 Pc Pack":  ["111","222","333","444","555","777","888","999","5011","5022","5033","5044","5055","5077","5088","5099","7011","7033","7055","7077","7099"],
  "FITLINE PRINTED 5 Pc Pack":   ["HUNTER"],
  "COMATE GYM VEST 5 Pc Pack":   ["2111","2333"],
  "COMATE GYM VEST DERBY":       ["2111"],
  // SHERA COMATE TRUNK/BRIEF
  "COMATE MINI TRUNK":           ["O/E"],
  "COMATE MINI TRUNK PRINT":     ["I/E"],
  "COMATE SMARTCUT BRIEF":       ["O/E"],
  "COMATE LONG TRUNK 2 Pc":      ["O/E","IE"],
  "COMATE PRINT LONG TRUNK":     ["IE"],
  "COMATE F.C.D 2 Pc Pack":      ["O/E"],
  "FIT LINE LYCRA TRUNK":        ["PRINT/PLAIN"],
  // SHERA ENJOY BERMUDAS LOUNGER
  "BERMUDA KIDS":                [],
  "BERMUDA PRINT":               [],
  "MERCERISED BERMUDA":          [],
  "ENJOY PLAIN BERMUDA":         ["5011","5022","5033"],
  "LOUNGER":                     ["1011","1022","1033","7077","7078"],
  "COMATE JUNIOR TRUNK":         [],
  // SHERA GOLD FINE VEST
  "SHERA GOLD FINE WHITE":       ["RN","RNS"],
  "SHERA GOLD FINE COLOUR":      ["RN","RNS"],
  // SHERA ANGEL PANTY & NURI SLIPS
  "ANGEL PLAIN 10 Pcs":          ["I/E"],
  "ANGEL PRINTED 10 Pcs":        ["I/E"],
  "NURI SLIPS WHITE":            ["C.P","LONG","SHORT"],
  "NURI SLIPS COLOUR":           ["C.P","LONG","SHORT"],
  // SHERA TRUNK/BRIEF & DRAWER
  "GOLD F.C.D":                  ["D.F"],
  "GOLD I.C.D PKT":              ["D.F"],
  "PARLE I.C.D":                 ["D.F"],
  "PARLE I.C.D PKT":             ["D.F"],
  "HI-MAN":                      ["O/E"],
  "SHERA DRAWER":                ["I/E","O/E"],
  "GOLD JUNIOR":                 ["I/E"],
  // ANGEL BLOOMER & KIDS DRAWER
  "ANGEL BLOOMER PLAIN":         ["I/E 10 Pcs"],
  "ANGEL BLOOMER PRINT":         ["I/E 10 Pcs"],
  "KIDS PRINT DRAWER":           ["I/E 10 Pcs"],
  "EON KIDS SORTY DRAWER":       ["I/E 10 Pcs"],
};

// Aliases — how salespersons write product names on order forms → canonical catalog name
const PRODUCT_ALIASES = {
  // VEST
  "COMATE RN":"COMATE WHITE 2 Pcs Pack",
  "COMATE WHITE RN":"COMATE WHITE 2 Pcs Pack",
  "COMATE RNS":"COMATE WHITE 2 Pcs Pack",
  "COMATE FINE":"COMATE WHITE 2 Pcs Pack",
  "COMATE FINE 2 PCS":"COMATE WHITE 2 Pcs Pack",
  "COMATE WHITE 2 PC":"COMATE WHITE 2 Pcs Pack",
  "PARKER":"COMATE PARKER",
  "PARKAR":"COMATE PARKER",
  // FITLINE GYM VEST
  "FITLINE":"FITLINE GYM VEST 5 Pc Pack",
  "FITLIN":"FITLINE GYM VEST 5 Pc Pack",
  "FIT LINE":"FITLINE GYM VEST 5 Pc Pack",
  "FITLINE GYM":"FITLINE GYM VEST 5 Pc Pack",
  "FIT LINE GYM VEST":"FITLINE GYM VEST 5 Pc Pack",
  "FITLINE GYM VEST":"FITLINE GYM VEST 5 Pc Pack",
  "FITLINE PRINTED":"FITLINE PRINTED 5 Pc Pack",
  "FITLINE PRINT":"FITLINE PRINTED 5 Pc Pack",
  // COMATE GYM VEST
  "COMATE GYM":"COMATE GYM VEST 5 Pc Pack",
  "COMATE GYM VEST":"COMATE GYM VEST 5 Pc Pack",
  "COMATE DERBY":"COMATE GYM VEST DERBY",
  "GYM VEST DERBY":"COMATE GYM VEST DERBY",
  // TRUNK/BRIEF
  "PLAIN MINI":"COMATE MINI TRUNK",
  "MINI PLAIN":"COMATE MINI TRUNK",
  "MINI TRUNK":"COMATE MINI TRUNK",
  "PLAIN MINI TRUNK":"COMATE MINI TRUNK",
  "PRINT MINI":"COMATE MINI TRUNK PRINT",
  "MINI PRINT":"COMATE MINI TRUNK PRINT",
  "PRINT MINI TRUNK":"COMATE MINI TRUNK PRINT",
  "MINI TRUNK PRINT":"COMATE MINI TRUNK PRINT",
  "SMART CUT":"COMATE SMARTCUT BRIEF",
  "SMARTCUT":"COMATE SMARTCUT BRIEF",
  "SMARTCUT BRIEF":"COMATE SMARTCUT BRIEF",
  "SMART CUT BRIEF":"COMATE SMARTCUT BRIEF",
  "PLAIN LONG":"COMATE LONG TRUNK 2 Pc",
  "LONG PLAIN":"COMATE LONG TRUNK 2 Pc",
  "LONG TRUNK":"COMATE LONG TRUNK 2 Pc",
  "PLAIN LONG TRUNK":"COMATE LONG TRUNK 2 Pc",
  "PRINT LONG":"COMATE PRINT LONG TRUNK",
  "LONG PRINT":"COMATE PRINT LONG TRUNK",
  "PRINT LONG TRUNK":"COMATE PRINT LONG TRUNK",
  "FIT LINE LYCRA":"FIT LINE LYCRA TRUNK",
  "FITLINE LYCRA":"FIT LINE LYCRA TRUNK",
  "LYCRA TRUNK":"FIT LINE LYCRA TRUNK",
  "FCD":"COMATE F.C.D 2 Pc Pack",
  "F.C.D":"COMATE F.C.D 2 Pc Pack",
  "COMATE FCD":"COMATE F.C.D 2 Pc Pack",
  // GOLD RANGE
  "GOLD RN W":"SHERA GOLD FINE WHITE",
  "GOLD RN WHITE":"SHERA GOLD FINE WHITE",
  "GOLD WHITE":"SHERA GOLD FINE WHITE",
  "GOLD FINE WHITE":"SHERA GOLD FINE WHITE",
  "GOLD RN COLOUR":"SHERA GOLD FINE COLOUR",
  "GOLD COLOUR":"SHERA GOLD FINE COLOUR",
  "GOLD FINE COLOUR":"SHERA GOLD FINE COLOUR",
  "GOLD FCD":"GOLD F.C.D",
  "GOLD ICD":"GOLD I.C.D PKT",
  "PARLE ICD":"PARLE I.C.D",
  "PARLE":"PARLE I.C.D",
  // DRAWER
  "GOLD DRAWER":"SHERA DRAWER",
  "SHERA DRAWER OE":"SHERA DRAWER",
  "SHERA DRAWER IE":"SHERA DRAWER",
  "DRAWER":"SHERA DRAWER",
  // ANGEL/NURI
  "ANGEL PLAIN":"ANGEL PLAIN 10 Pcs",
  "ANGEL PANTY PLAIN":"ANGEL PLAIN 10 Pcs",
  "ANGEL PRINTED":"ANGEL PRINTED 10 Pcs",
  "ANGEL PANTY PRINT":"ANGEL PRINTED 10 Pcs",
  "ANGEL PRINT":"ANGEL PRINTED 10 Pcs",
  "ANGEL BLOOMER":"ANGEL BLOOMER PLAIN",
  "NURI WHITE":"NURI SLIPS WHITE",
  "NURI COLOUR":"NURI SLIPS COLOUR",
  // BERMUDA/LOUNGER
  "BERMUDA":"BERMUDA KIDS",
  "ENJOY BERMUDA":"ENJOY PLAIN BERMUDA",
  // DOTTIE (not in catalog — keep for backwards compat)
  "DOTTIE PANTY":"DOTTIE LYCRA PANTY PLAIN",
  "DOTTIE LYCRA PANTY":"DOTTIE LYCRA PANTY PLAIN",
  "DOTTIE":"DOTTIE LYCRA PANTY PLAIN",
};

// ── PDF engine ────────────────────────────────────────────────────────────────
function pe(s){ return String(s??"").replace(/\\/g,"\\\\").replace(/\(/g,"\\(").replace(/\)/g,"\\)"); }
function tw(t,sz,f=0.56){ return String(t??"").length*sz*f; }
function clip(t,sz,max){ let s=String(t??""); if(tw(s,sz)<=max-4)return s; while(s.length>1&&tw(s+"…",sz)>max-4)s=s.slice(0,-1); return s+"…"; }
function txt(x,y,sz,t,bold=false){ return `BT /${bold?"F2":"F1"} ${sz} Tf 1 0 0 1 ${x.toFixed(2)} ${y.toFixed(2)} Tm (${pe(t)}) Tj ET`; }
function rect(x,y,w,h,lw=0.5){ return `${lw} w ${x.toFixed(2)} ${y.toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re S`; }
function fillRect(x,y,w,h,rgb){ return `${rgb[0]} ${rgb[1]} ${rgb[2]} rg ${x.toFixed(2)} ${y.toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re f 0 0 0 rg`; }
// Place text: align l/c/r, vertically bottom-aligned at 3pt from bottom
function cell(ops,x,y,w,h,t,sz,bold,align="l"){
  if(t===undefined||t===null||t==="")return;
  const s=String(t); const cl=clip(s,sz,w);
  const tx = align==="c"?x+(w-tw(cl,sz))/2 : align==="r"?x+w-tw(cl,sz)-3 : x+3;
  ops.push(txt(tx, y+3, sz, cl, bold));  // y+3 = 3pt from bottom of cell
}

function wrapDoc(cs){
  const o={};
  o[1]=`1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n`;
  o[2]=`2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n`;
  o[3]=`3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PW} ${PH}] /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> /Contents 4 0 R >>\nendobj\n`;
  o[4]=`4 0 obj\n<< /Length ${cs.length} >>\nstream\n${cs}\nendstream\nendobj\n`;
  o[5]=`5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n`;
  o[6]=`6 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>\nendobj\n`;
  let body="%PDF-1.4\n"; const offs={};
  for(let n=1;n<=6;n++){offs[n]=body.length;body+=o[n];}
  const xo=body.length;
  let x=`xref\n0 7\n0000000000 65535 f \n`;
  for(let n=1;n<=6;n++)x+=String(offs[n]).padStart(10,"0")+" 00000 n \n";
  return body+x+`trailer\n<< /Size 7 /Root 1 0 R >>\nstartxref\n${xo}\n%%EOF`;
}

function buildPdf(p){
  const ops=[];
  const TW = COL_QUALITY+COL_SHAPE+COL_SIZE*16+COL_TOTAL+COL_CASE+COL_GTOTAL;

  // Top margin = 56pt (exact from sample PDF measurement)
  const TOP_MARGIN = 56;
  const fixedHeight = TOP_MARGIN + RH_TITLE + RH_INFO + RH_REMARKS + RH_HEADER;
  const usedHeight = fixedHeight + (p.rows||[]).length * RH_BODY + RH_GTOTAL;
  const emptyRowCount = Math.max(0, Math.floor((PH - usedHeight) / RH_BODY));

  let y = PH - TOP_MARGIN;

  // ── TITLE ROW ──
  y -= RH_TITLE;
  ops.push(rect(ML, y, TW, RH_TITLE, 0.5));
  const titleTxt = "SHERA HOSIERY ORDER RATIO";
  const titleSz = 12;
  ops.push(txt(ML+(TW-tw(titleTxt,titleSz))/2, y+4, titleSz, titleTxt, false));

  // ── INFO ROW ──
  y -= RH_INFO;
  const infoCols = [
    {x:ML,    w:119-ML,      t:`Ord No. ${p.orderId||""}`},
    {x:119,   w:213.5-119,   t:`Date: ${p.date||""}`},
    {x:213.5, w:482.4-213.5, t:`Party Name: ${p.partyName||""}`},
    {x:482.4, w:609.2-482.4, t:`Town: ${p.partyTown||""}`},
    {x:609.2, w:ML+TW-609.2, t:`Or From : R K MERCHANDISE`},
  ];
  ops.push(rect(ML, y, TW, RH_INFO, 0.5));
  [119,213.5,482.4,609.2].forEach(dx=>{
    ops.push(`0.5 w ${dx.toFixed(1)} ${y.toFixed(1)} m ${dx.toFixed(1)} ${(y+RH_INFO).toFixed(1)} l S`);
  });
  infoCols.forEach(c=>cell(ops,c.x,y,c.w,RH_INFO,c.t,9,true,"l"));

  // ── REMARKS ROW ──
  y -= RH_REMARKS;
  ops.push(rect(ML, y, TW, RH_REMARKS, 0.5));
  cell(ops,ML,y,TW,RH_REMARKS,`REMARKS : ${(p.remarks||"").toUpperCase()}`,9,true,"l");

  // ── YELLOW HEADER ROW ──
  y -= RH_HEADER;
  ops.push(fillRect(ML,y,TW,RH_HEADER,YELLOW_PDF));
  ops.push(rect(ML,y,TW,RH_HEADER,0.5));

  // QUALITY — 12pt bold bottom-aligned
  ops.push(`0.5 w ${(ML+COL_QUALITY).toFixed(1)} ${y.toFixed(1)} m ${(ML+COL_QUALITY).toFixed(1)} ${(y+RH_HEADER).toFixed(1)} l S`);
  ops.push(txt(ML+3, y+4, 12, "QUALITY", true));

  // Shape — 9pt bold (fits the narrower column, matches sample visually)
  const shpX = ML+COL_QUALITY;
  ops.push(`0.5 w ${(shpX+COL_SHAPE).toFixed(1)} ${y.toFixed(1)} m ${(shpX+COL_SHAPE).toFixed(1)} ${(y+RH_HEADER).toFixed(1)} l S`);
  ops.push(txt(shpX+3, y+4, 9, "Shape", true));

  // Size columns — 8pt bold, centred, bottom-aligned
  let sx = ML+COL_QUALITY+COL_SHAPE;
  SIZES.forEach(s=>{
    ops.push(`0.5 w ${(sx+COL_SIZE).toFixed(1)} ${y.toFixed(1)} m ${(sx+COL_SIZE).toFixed(1)} ${(y+RH_HEADER).toFixed(1)} l S`);
    const sz=8;
    if(s==="95 XL"){
      ops.push(txt(sx+(COL_SIZE-tw("95",sz))/2, y+RH_HEADER-12, sz,"95",true));
      ops.push(txt(sx+(COL_SIZE-tw("XL",sz))/2, y+4,            sz,"XL",true));
    } else if(s==="100 XXL"){
      ops.push(txt(sx+(COL_SIZE-tw("100",sz))/2,y+RH_HEADER-12,sz,"100",true));
      ops.push(txt(sx+(COL_SIZE-tw("XXL",sz))/2,y+4,           sz,"XXL",true));
    } else {
      ops.push(txt(sx+(COL_SIZE-tw(s,sz))/2, y+4, sz, s, true));
    }
    sx+=COL_SIZE;
  });

  // Total / Case / G.TOTAL
  const totX=ML+COL_QUALITY+COL_SHAPE+COL_SIZE*16;
  ops.push(`0.5 w ${(totX+COL_TOTAL).toFixed(1)} ${y.toFixed(1)} m ${(totX+COL_TOTAL).toFixed(1)} ${(y+RH_HEADER).toFixed(1)} l S`);
  ops.push(`0.5 w ${(totX+COL_TOTAL+COL_CASE).toFixed(1)} ${y.toFixed(1)} m ${(totX+COL_TOTAL+COL_CASE).toFixed(1)} ${(y+RH_HEADER).toFixed(1)} l S`);
  [{t:"Total",w:COL_TOTAL},{t:"Case",w:COL_CASE},{t:"G.TOTAL",w:COL_GTOTAL}].forEach((c,i)=>{
    const cx=totX+[0,COL_TOTAL,COL_TOTAL+COL_CASE][i];
    ops.push(txt(cx+(c.w-tw(c.t,8))/2, y+4, 8, c.t, true));
  });

  // ── BODY ROWS ──
  let grandTotal=0, grandCase=0, grandGTotal=0;
  const drawRow=(r,isEmpty)=>{
    y -= RH_BODY;
    ops.push(rect(ML,y,TW,RH_BODY,0.5));
    ops.push(`0.5 w ${(ML+COL_QUALITY).toFixed(1)} ${y.toFixed(1)} m ${(ML+COL_QUALITY).toFixed(1)} ${(y+RH_BODY).toFixed(1)} l S`);
    ops.push(`0.5 w ${(ML+COL_QUALITY+COL_SHAPE).toFixed(1)} ${y.toFixed(1)} m ${(ML+COL_QUALITY+COL_SHAPE).toFixed(1)} ${(y+RH_BODY).toFixed(1)} l S`);
    const tX=ML+COL_QUALITY+COL_SHAPE+COL_SIZE*16;
    ops.push(`0.5 w ${(tX+COL_TOTAL).toFixed(1)} ${y.toFixed(1)} m ${(tX+COL_TOTAL).toFixed(1)} ${(y+RH_BODY).toFixed(1)} l S`);
    ops.push(`0.5 w ${(tX+COL_TOTAL+COL_CASE).toFixed(1)} ${y.toFixed(1)} m ${(tX+COL_TOTAL+COL_CASE).toFixed(1)} ${(y+RH_BODY).toFixed(1)} l S`);
    let cX=ML+COL_QUALITY+COL_SHAPE;
    SIZES.forEach(()=>{ops.push(`0.5 w ${(cX+COL_SIZE).toFixed(1)} ${y.toFixed(1)} m ${(cX+COL_SIZE).toFixed(1)} ${(y+RH_BODY).toFixed(1)} l S`);cX+=COL_SIZE;});
    if(isEmpty)return;
    cell(ops,ML,y,COL_QUALITY,RH_BODY,r.product,8,false,"l");
    cell(ops,ML+COL_QUALITY,y,COL_SHAPE,RH_BODY,r.variant,8,false,"c");
    let rowTotal=0; cX=ML+COL_QUALITY+COL_SHAPE;
    SIZES.forEach(s=>{
      const q=r.sizes?.[s];
      if(q){rowTotal+=parseFloat(q)||0;cell(ops,cX,y,COL_SIZE,RH_BODY,""+q,8,false,"c");}
      cX+=COL_SIZE;
    });
    grandTotal+=rowTotal;
    const cv=r.caseVal||1; const gt=rowTotal||"";
    grandCase=Math.max(grandCase,cv);
    if(gt!=="")grandGTotal+=gt;
    if(rowTotal)cell(ops,tX,y,COL_TOTAL,RH_BODY,""+rowTotal,8,false,"c");
    cell(ops,tX+COL_TOTAL,y,COL_CASE,RH_BODY,""+cv,8,false,"c");
    if(gt!=="")cell(ops,tX+COL_TOTAL+COL_CASE,y,COL_GTOTAL,RH_BODY,""+gt,8,false,"c");
  };

  (p.rows||[]).forEach(r=>drawRow(r,false));
  for(let i=0;i<emptyRowCount;i++)drawRow(null,true);

  // ── GRAND TOTAL ROW ──
  y -= RH_GTOTAL;
  ops.push(rect(ML,y,TW,RH_GTOTAL,0.5));
  ops.push(`0.5 w ${(ML+COL_QUALITY).toFixed(1)} ${y.toFixed(1)} m ${(ML+COL_QUALITY).toFixed(1)} ${(y+RH_GTOTAL).toFixed(1)} l S`);
  ops.push(`0.5 w ${(ML+COL_QUALITY+COL_SHAPE).toFixed(1)} ${y.toFixed(1)} m ${(ML+COL_QUALITY+COL_SHAPE).toFixed(1)} ${(y+RH_GTOTAL).toFixed(1)} l S`);
  const tX2=ML+COL_QUALITY+COL_SHAPE+COL_SIZE*16;
  ops.push(`0.5 w ${(tX2+COL_TOTAL).toFixed(1)} ${y.toFixed(1)} m ${(tX2+COL_TOTAL).toFixed(1)} ${(y+RH_GTOTAL).toFixed(1)} l S`);
  ops.push(`0.5 w ${(tX2+COL_TOTAL+COL_CASE).toFixed(1)} ${y.toFixed(1)} m ${(tX2+COL_TOTAL+COL_CASE).toFixed(1)} ${(y+RH_GTOTAL).toFixed(1)} l S`);
  let cX2=ML+COL_QUALITY+COL_SHAPE;
  SIZES.forEach(()=>{ops.push(`0.5 w ${(cX2+COL_SIZE).toFixed(1)} ${y.toFixed(1)} m ${(cX2+COL_SIZE).toFixed(1)} ${(y+RH_GTOTAL).toFixed(1)} l S`);cX2+=COL_SIZE;});
  cell(ops,ML,y,COL_QUALITY,RH_GTOTAL,"GRAND TOTAL",8,true,"l");
  cell(ops,tX2,y,COL_TOTAL,RH_GTOTAL,""+grandTotal,8,true,"c");
  cell(ops,tX2+COL_TOTAL,y,COL_CASE,RH_GTOTAL,""+grandCase,8,true,"c");
  cell(ops,tX2+COL_TOTAL+COL_CASE,y,COL_GTOTAL,RH_GTOTAL,""+grandGTotal,8,true,"c");

  return wrapDoc(ops.join("\n"));
}


// ── AI parsing ────────────────────────────────────────────────────────────────
async function parseOrderImages(imageDataList){
  const today=new Date().toLocaleDateString("en-IN",{day:"2-digit",month:"2-digit",year:"numeric"}).replace(/\//g,"-");
  const catalogLines=Object.entries(PRODUCT_CATALOG).map(([p,vs])=>`  "${p}"${vs.length?` → shapes: ${vs.join(", ")}`:"" }`).join("\n");
  const content=[
    ...imageDataList.map(img=>({type:"image",source:{type:"base64",media_type:img.mediaType,data:img.base64}})),
    {type:"text",text:`You are reading a SHERA HOSIERY ORDER RATIO form. QUALITY column = product name. Shape column = variant/shape code.

PRODUCT CATALOG (use exact names):
${catalogLines}

SIZE COLUMN KEYS (use exactly): ${SIZES.join(", ")}

IMPORTANT SIZE MAPPING — the order form may use different size labels. Map them to our standard keys:
- 75 or 75/30 → 75/30
- 80 or 80/32 or 80/S → 80/S
- 85 or 85/34 or 85/M → 85/M
- 90 or 90/36 or 90/L → 90/L
- 95 or 95/38 or 95/XL → 95 XL
- 100 or 100/40 or 100/XXL → 100 XXL
- 105 or 105/42 → 105
- 110 or 110/44 → 110
- 115 or 115/46 → 110 (map to nearest)

Today if date not visible: ${today}

Return ONLY valid JSON:
{
  "orderId": "RK 106",
  "date": "15-01-2026",
  "partyName": "V M TRADERS",
  "partyEmail": "",
  "partyTown": "PIMPRI",
  "orFrom": "R K MERCHANDISE",
  "remarks": "MOST URGENT",
  "rows": [
    { "product": "FIT LINE GYM VEST", "variant": "2111", "caseVal": 1, "sizes": { "80/S": 10, "85/M": 40, "90/L": 14, "95 XL": 20, "100 XXL": 12 } }
  ],
  "cartonSummary": []
}

Rules: product must match catalog exactly. Only include sizes with non-zero qty. Return ONLY the JSON.`}
  ];
  const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({model:"claude-sonnet-4-6",max_tokens:3000,messages:[{role:"user",content}]})});
  const data=await res.json();
  const text=data.content?.find(b=>b.type==="text")?.text||"{}";
  return JSON.parse(text.replace(/```json|```/g,"").trim());
}

async function sendOrderEmail(p,pdfB64){
  if(!window.emailjs){
    await new Promise((res,rej)=>{const s=document.createElement("script");s.src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js";s.onload=res;s.onerror=rej;document.head.appendChild(s);});
    window.emailjs.init(EMAILJS_PUBLIC_KEY);
  }
  return window.emailjs.send(EMAILJS_SERVICE_ID,EMAILJS_TEMPLATE_ID,{
    to_email:p.partyEmail,party_name:p.partyName,order_id:p.orderId,order_date:p.date,
    pdf_attachment:pdfB64,pdf_filename:`${(p.orderId||"order").replace(/ /g,"_")}.pdf`,
  });
}
function toB64(str){const b=new Uint8Array(str.length);for(let i=0;i<str.length;i++)b[i]=str.charCodeAt(i);let s="";b.forEach(x=>s+=String.fromCharCode(x));return btoa(s);}

// ── UI tokens ─────────────────────────────────────────────────────────────────
const C={bg:"#F4F1EB",card:"#FFF",border:"#DDD8CC",dark:"#1A1A2E",mid:"#5A5A72",light:"#9A9AAF",red:"#C0392B",green:"#27AE60",shadow:"0 2px 12px rgba(0,0,0,.08)"};
const sans="'Inter',system-ui,sans-serif";
const serif="'Georgia',serif";

// ── App ───────────────────────────────────────────────────────────────────────
export default function App(){
  const [images,setImages]=useState([]);
  const [step,setStep]=useState("upload");
  const [parsed,setParsed]=useState(null);
  const [edit,setEdit]=useState({});
  const [error,setError]=useState("");
  const [emailStatus,setEmailStatus]=useState("");
  const fileRef=useRef(); const dropRef=useRef();

  const readFiles=useCallback(async(files)=>{
    const imgs=[];
    for(const f of [...files]){
      if(!f.type.startsWith("image/"))continue;
      const b64=await new Promise(res=>{const r=new FileReader();r.onload=()=>res(r.result.split(",")[1]);r.readAsDataURL(f);});
      imgs.push({url:URL.createObjectURL(f),base64:b64,mediaType:f.type});
    }
    setImages(p=>[...p,...imgs]);
  },[]);

  const onDrop=useCallback(e=>{e.preventDefault();dropRef.current?.classList.remove("dov");readFiles(e.dataTransfer.files);},[readFiles]);

  const scan=async()=>{
    setStep("scanning");setError("");
    try{
      const data=await parseOrderImages(images);
      setParsed(data);
      setEdit({orderId:data.orderId||"",date:data.date||"",partyName:data.partyName||"",
               partyEmail:data.partyEmail||"",partyTown:data.partyTown||"",
               orFrom:data.orFrom||"R K MERCHANDISE",remarks:data.remarks||""});
      setStep("review");
    }catch(e){setError("Could not read order — check image quality and try again.");setStep("upload");}
  };

  const merged=()=>({...parsed,...edit});

  const downloadPdf=()=>{
    const str=buildPdf(mergedWithRows());
    const a=document.createElement("a");
    a.href=URL.createObjectURL(new Blob([str],{type:"application/pdf"}));
    a.download=`${edit.orderId||"order"}.pdf`;
    document.body.appendChild(a);a.click();document.body.removeChild(a);
  };

  const sendEmail=async()=>{
    if(!edit.partyEmail){setError("Enter party email first.");return;}
    setStep("sending");setError("");
    try{
      const str=buildPdf(mergedWithRows());
      await sendOrderEmail(mergedWithRows(),toB64(str));
      setEmailStatus(`Sent to ${edit.partyEmail}`);
      setStep("done");
    }catch(e){setError("Email failed: "+(e?.text||e?.message||String(e)));setStep("review");}
  };

  const reset=()=>{setImages([]);setParsed(null);setStep("upload");setError("");setEdit({});setEmailStatus("");};
  const stepIdx=step==="upload"?0:step==="scanning"?1:step==="review"||step==="sending"?2:3;

  // editRows: fully editable rows state separate from parsed
  const [editRows,setEditRows]=useState([]);

  // When parsed changes, sync editRows
  const prevParsedRef=useRef(null);
  if(parsed&&parsed!==prevParsedRef.current){
    prevParsedRef.current=parsed;
    setEditRows((parsed.rows||[]).map(r=>({...r,sizes:{...r.sizes}})));
  }

  const updateRow=(i,field,val)=>setEditRows(rows=>rows.map((r,idx)=>idx===i?{...r,[field]:val}:r));
  const updateSize=(i,size,val)=>setEditRows(rows=>rows.map((r,idx)=>idx===i?{...r,sizes:{...r.sizes,[size]:val===''?undefined:val}}:r));
  const addRow=()=>setEditRows(rows=>[...rows,{product:"",variant:"",caseVal:1,sizes:{}}]);
  const deleteRow=(i)=>setEditRows(rows=>rows.filter((_,idx)=>idx!==i));

  const computedRows=editRows.map(r=>({
    ...r,
    total:Object.values(r.sizes||{}).reduce((s,v)=>s+(parseFloat(v)||0),0)
  }));
  const grandTotalPrev=computedRows.reduce((s,r)=>s+r.total,0);

  // Override merged() to use editRows
  const mergedWithRows=()=>({...parsed,...edit,rows:editRows});

  return(
    <div style={{minHeight:"100vh",background:C.bg,fontFamily:sans,padding:"20px 12px"}}>
      <style>{`
        *{box-sizing:border-box}
        .drop{border:2px dashed ${C.border};border-radius:10px;padding:36px 20px;text-align:center;cursor:pointer;background:${C.card};transition:border-color .2s,background .2s}
        .drop.dov{border-color:#FFFF00;background:#FFFFD0}
        .thumb{position:relative;border-radius:6px;overflow:hidden;border:1px solid ${C.border}}
        .thumb img{width:100%;height:100px;object-fit:cover;display:block}
        .thumb .rm{position:absolute;top:3px;right:3px;background:rgba(0,0,0,.55);color:#fff;border:none;border-radius:50%;width:20px;height:20px;cursor:pointer;font-size:10px;display:flex;align-items:center;justify-content:center}
        .thumb .pg{position:absolute;bottom:0;left:0;right:0;background:rgba(0,0,0,.45);color:#fff;font-size:9px;padding:2px 4px;text-align:center}
        .btn{display:inline-flex;align-items:center;gap:6px;padding:9px 18px;border-radius:7px;border:none;font-size:13px;font-weight:700;cursor:pointer;transition:opacity .15s;font-family:${sans}}
        .btn:hover{opacity:.85}.btn:disabled{opacity:.4;cursor:not-allowed}
        @keyframes spin{to{transform:rotate(360deg)}}
        .spin{width:28px;height:28px;border:3px solid ${C.border};border-top-color:${C.dark};border-radius:50%;animation:spin .7s linear infinite;margin:0 auto 12px}
        .steps{display:flex;border-radius:7px;overflow:hidden;border:1px solid ${C.border};margin-top:12px}
        .step{flex:1;padding:7px 4px;text-align:center;font-size:11px;font-weight:700;border-right:1px solid ${C.border}}
        .step:last-child{border-right:none}
        /* Preview table — exact replica of PDF format */
        .pv{border-collapse:collapse;font-family:'Arial',sans-serif;width:100%}
        .pv td,.pv th{border:1px solid #000;padding:0;margin:0;font-size:8px;white-space:nowrap}
        .pv .title{text-align:center;font-weight:700;font-size:12px;padding:4px}
        .pv .info{font-weight:700;font-size:9px;padding:2px 3px}
        .pv .rem{font-weight:700;font-size:9px;padding:2px 3px}
        .pv .hdr{background:${YELLOW_CSS};font-weight:700;font-size:8px;text-align:center;padding:3px 2px}
        .pv .hdr-q{background:${YELLOW_CSS};font-weight:700;font-size:11px;padding:4px 3px;text-align:left}
        .pv .hdr-s{background:${YELLOW_CSS};font-weight:700;font-size:10px;padding:4px 3px}
        .pv .body-q{font-size:8px;padding:2px 3px;min-width:120px}
        .pv .body-c{font-size:8px;padding:2px 3px;text-align:center}
        .pv .gt{font-weight:700;font-size:8px;padding:2px 3px}
        .pv input{border:none;outline:none;background:transparent;font-family:'Arial',sans-serif;font-weight:700;width:100%}
      `}</style>

      {/* Header */}
      <div style={{maxWidth:980,margin:"0 auto 20px"}}>
        <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:2}}>
          <div style={{width:38,height:38,background:C.dark,borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>📋</div>
          <div>
            <h1 style={{margin:0,fontFamily:serif,fontSize:20,color:C.dark,fontWeight:700}}>Shrea Order Scanner</h1>
            <p style={{margin:0,fontSize:11,color:C.light}}>Photo → AI reads → exact PDF → send to party</p>
          </div>
        </div>
        <div className="steps">
          {["1. Upload","2. AI Scan","3. Review & Edit","4. Send"].map((s,i)=>(
            <div key={s} className="step" style={{background:i===stepIdx?C.dark:i<stepIdx?C.green:"#F0EDE8",color:i<=stepIdx?"#fff":C.light}}>
              {i<stepIdx?"✓ ":""}{s}
            </div>
          ))}
        </div>
      </div>

      <div style={{maxWidth:980,margin:"0 auto",display:"flex",flexDirection:"column",gap:14}}>
        {error&&<div style={{background:"#FDEDEC",border:`1px solid ${C.red}`,borderRadius:7,padding:"9px 13px",fontSize:13,color:C.red,fontWeight:600}}>{error}</div>}

        {/* UPLOAD */}
        {step==="upload"&&(
          <div style={{background:C.card,borderRadius:10,border:`1px solid ${C.border}`,padding:20,boxShadow:C.shadow}}>
            <h2 style={{margin:"0 0 12px",fontFamily:serif,fontSize:15,color:C.dark}}>Upload Order Photos</h2>
            <div className="drop" ref={dropRef}
              onDragOver={e=>{e.preventDefault();dropRef.current?.classList.add("dov")}}
              onDragLeave={()=>dropRef.current?.classList.remove("dov")}
              onDrop={onDrop} onClick={()=>fileRef.current?.click()}>
              <div style={{fontSize:36,marginBottom:6}}>📷</div>
              <p style={{margin:0,fontSize:13,fontWeight:700,color:C.dark}}>Drag photos here or tap to select</p>
              <p style={{margin:"3px 0 0",fontSize:11,color:C.light}}>Multiple pages · JPG, PNG, HEIC · printed or handwritten</p>
              <input ref={fileRef} type="file" accept="image/*" multiple style={{display:"none"}} onChange={e=>readFiles(e.target.files)}/>
            </div>
            {images.length>0&&<>
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(100px,1fr))",gap:8,marginTop:12}}>
                {images.map((img,i)=>(
                  <div key={i} className="thumb">
                    <img src={img.url} alt={`Page ${i+1}`}/>
                    <button className="rm" onClick={e=>{e.stopPropagation();setImages(p=>p.filter((_,j)=>j!==i))}}>✕</button>
                    <div className="pg">Page {i+1}</div>
                  </div>
                ))}
              </div>
              <div style={{marginTop:16,display:"flex",justifyContent:"flex-end"}}>
                <button className="btn" style={{background:C.dark,color:"#fff"}} onClick={scan}>
                  🔍 Scan {images.length} photo{images.length>1?"s":""} with AI
                </button>
              </div>
            </>}
          </div>
        )}

        {/* SCANNING */}
        {step==="scanning"&&(
          <div style={{background:C.card,borderRadius:10,border:`1px solid ${C.border}`,padding:48,textAlign:"center",boxShadow:C.shadow}}>
            <div className="spin"/>
            <h2 style={{fontFamily:serif,fontSize:17,color:C.dark,margin:"0 0 6px"}}>Reading order…</h2>
            <p style={{color:C.light,fontSize:12,margin:0}}>AI extracting products, shapes &amp; quantities</p>
          </div>
        )}

        {/* REVIEW — exact PDF replica */}
        {step==="review"&&parsed&&<>
          <div style={{background:C.card,borderRadius:10,border:`1px solid ${C.border}`,padding:16,boxShadow:C.shadow}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
              <h2 style={{margin:0,fontFamily:serif,fontSize:14,color:C.dark}}>Order Preview — click any field to edit</h2>
              <span style={{fontSize:10,color:C.light}}>Exact PDF format</span>
            </div>
            <div style={{overflowX:"auto"}}>
              <table className="pv" style={{minWidth:760}}>
                {/* TITLE */}
                <tbody>
                <tr><td colSpan={22} className="title">SHERA HOSIERY ORDER RATIO</td></tr>

                {/* INFO ROW */}
                <tr>
                  <td colSpan={2} className="info" style={{whiteSpace:"nowrap"}}>
                    Ord No.&nbsp;<input value={edit.orderId||""} onChange={e=>setEdit(f=>({...f,orderId:e.target.value}))} style={{width:60,fontSize:9}}/>
                  </td>
                  <td colSpan={2} className="info" style={{whiteSpace:"nowrap"}}>
                    Date:&nbsp;<input value={edit.date||""} onChange={e=>setEdit(f=>({...f,date:e.target.value}))} style={{width:80,fontSize:9}}/>
                  </td>
                  <td colSpan={9} className="info">
                    Party Name:&nbsp;<input value={edit.partyName||""} onChange={e=>setEdit(f=>({...f,partyName:e.target.value}))} style={{width:160,fontSize:9}}/>
                  </td>
                  <td colSpan={5} className="info" style={{whiteSpace:"nowrap"}}>
                    Town:&nbsp;<input value={edit.partyTown||""} onChange={e=>setEdit(f=>({...f,partyTown:e.target.value}))} style={{width:70,fontSize:9}}/>
                  </td>
                  <td colSpan={4} className="info" style={{whiteSpace:"nowrap"}}>
                    Or From:&nbsp;<input value={edit.orFrom||""} onChange={e=>setEdit(f=>({...f,orFrom:e.target.value}))} style={{width:90,fontSize:9}}/>
                  </td>
                </tr>

                {/* REMARKS */}
                <tr>
                  <td colSpan={22} className="rem">
                    REMARKS :&nbsp;<input value={edit.remarks||""} onChange={e=>setEdit(f=>({...f,remarks:e.target.value}))} style={{width:"85%",fontSize:9,textTransform:"uppercase"}}/>
                  </td>
                </tr>

                {/* YELLOW HEADER — two rows exactly like PDF: "95"/"100" on top, rest on bottom */}
                {/* Top mini-row: only 95 XL and 100 XXL have top labels */}
                <tr style={{background:YELLOW_CSS}}>
                  <td colSpan={2} rowSpan={2} style={{border:"1px solid #000",fontWeight:700,fontSize:12,padding:"3px 4px",verticalAlign:"bottom",minWidth:130}}>QUALITY</td>
                  <td rowSpan={2} style={{border:"1px solid #000",background:YELLOW_CSS,fontWeight:700,fontSize:10,padding:"3px 4px",verticalAlign:"bottom",textAlign:"center",minWidth:36}}>Shape</td>
                  {SIZES.slice(0,13).map(s=>(
                    <td key={s} style={{border:"1px solid #000",background:YELLOW_CSS,fontWeight:700,fontSize:7,padding:"1px 1px",textAlign:"center",verticalAlign:"bottom",minWidth:22}}>
                      {s==="95 XL"?"95":""}
                    </td>
                  ))}
                  <td style={{border:"1px solid #000",background:YELLOW_CSS,fontWeight:700,fontSize:7,padding:"1px 1px",textAlign:"center",verticalAlign:"bottom",minWidth:22}}>100</td>
                  <td style={{border:"1px solid #000",background:YELLOW_CSS,padding:"1px",verticalAlign:"bottom",minWidth:22}}></td>
                  <td style={{border:"1px solid #000",background:YELLOW_CSS,padding:"1px",verticalAlign:"bottom",minWidth:22}}></td>
                  <td rowSpan={2} style={{border:"1px solid #000",background:YELLOW_CSS,fontWeight:700,fontSize:8,padding:"3px 2px",verticalAlign:"bottom",textAlign:"center",minWidth:28}}>Total</td>
                  <td rowSpan={2} style={{border:"1px solid #000",background:YELLOW_CSS,fontWeight:700,fontSize:8,padding:"3px 2px",verticalAlign:"bottom",textAlign:"center",minWidth:28}}>Case</td>
                  <td rowSpan={2} style={{border:"1px solid #000",background:YELLOW_CSS,fontWeight:700,fontSize:8,padding:"3px 2px",verticalAlign:"bottom",textAlign:"center",minWidth:40}}>G.TOTAL</td>
                </tr>
                <tr style={{background:YELLOW_CSS}}>
                  {SIZES.slice(0,13).map(s=>(
                    <td key={s} style={{border:"1px solid #000",background:YELLOW_CSS,fontWeight:700,fontSize:7,padding:"1px 1px",textAlign:"center",verticalAlign:"bottom",minWidth:22}}>
                      {s==="95 XL"?"XL":s}
                    </td>
                  ))}
                  <td style={{border:"1px solid #000",background:YELLOW_CSS,fontWeight:700,fontSize:7,padding:"1px 1px",textAlign:"center",verticalAlign:"bottom"}}>XXL</td>
                  <td style={{border:"1px solid #000",background:YELLOW_CSS,fontWeight:700,fontSize:7,padding:"1px 1px",textAlign:"center",verticalAlign:"bottom"}}>105</td>
                  <td style={{border:"1px solid #000",background:YELLOW_CSS,fontWeight:700,fontSize:7,padding:"1px 1px",textAlign:"center",verticalAlign:"bottom"}}>110</td>
                </tr>

                {/* PRODUCT ROWS — fully editable */}
                {computedRows.map((r,i)=>(
                  <tr key={i}>
                    <td colSpan={2} style={{border:"1px solid #000",padding:0,minWidth:130}}>
                      <input value={r.product||""} onChange={e=>updateRow(i,"product",e.target.value)}
                        style={{width:"100%",border:"none",outline:"none",background:"transparent",fontFamily:"Arial,sans-serif",fontSize:8,padding:"2px 3px",boxSizing:"border-box"}}
                        placeholder="Product name"/>
                    </td>
                    <td style={{border:"1px solid #000",padding:0,minWidth:36}}>
                      <input value={r.variant||""} onChange={e=>updateRow(i,"variant",e.target.value)}
                        style={{width:"100%",border:"none",outline:"none",background:"transparent",fontFamily:"Arial,sans-serif",fontSize:8,padding:"2px 2px",textAlign:"center",boxSizing:"border-box"}}
                        placeholder="Shape"/>
                    </td>
                    {SIZES.map(s=>(
                      <td key={s} style={{border:"1px solid #000",padding:0,minWidth:22}}>
                        <input type="number" min="0" value={r.sizes?.[s]||""}
                          onChange={e=>updateSize(i,s,e.target.value)}
                          style={{width:"100%",border:"none",outline:"none",background:r.sizes?.[s]?"#fffff0":"transparent",fontFamily:"Arial,sans-serif",fontSize:8,padding:"2px 1px",textAlign:"center",boxSizing:"border-box"}}/>
                      </td>
                    ))}
                    <td style={{border:"1px solid #000",padding:"2px 3px",textAlign:"center",fontWeight:700,fontSize:8,minWidth:24,background:"#f5f5f5"}}>{r.total||""}</td>
                    <td style={{border:"1px solid #000",padding:0,minWidth:24}}>
                      <input type="number" min="1" value={r.caseVal||1} onChange={e=>updateRow(i,"caseVal",parseInt(e.target.value)||1)}
                        style={{width:"100%",border:"none",outline:"none",background:"transparent",fontFamily:"Arial,sans-serif",fontSize:8,padding:"2px 1px",textAlign:"center",boxSizing:"border-box"}}/>
                    </td>
                    <td style={{border:"1px solid #000",padding:"2px 3px",textAlign:"center",fontWeight:700,fontSize:8,minWidth:30,background:"#f5f5f5"}}>{r.total||""}</td>
                    <td style={{border:"none",padding:"0 3px",background:"transparent"}}>
                      <button onClick={()=>deleteRow(i)} title="Delete row"
                        style={{background:"none",border:"none",cursor:"pointer",color:C.red,fontSize:13,padding:0,lineHeight:1}}>✕</button>
                    </td>
                  </tr>
                ))}

                {/* ADD ROW */}
                <tr>
                  <td colSpan={23} style={{border:"1px dashed #ccc",padding:"3px 6px",background:"#fafafa"}}>
                    <button onClick={addRow}
                      style={{background:"none",border:"none",cursor:"pointer",color:C.green,fontSize:11,fontWeight:700,padding:0}}>
                      ＋ Add Row
                    </button>
                  </td>
                </tr>

                {/* GRAND TOTAL */}
                <tr>
                  <td colSpan={2} className="gt" style={{verticalAlign:"bottom"}}>GRAND TOTAL</td>
                  <td className="body-c" style={{verticalAlign:"bottom"}}></td>
                  {SIZES.map(s=>{
                    const col=computedRows.reduce((sum,r)=>sum+(parseFloat(r.sizes?.[s])||0),0);
                    return <td key={s} className="body-c" style={{fontWeight:700,verticalAlign:"bottom"}}>{col||""}</td>;
                  })}
                  <td className="body-c" style={{fontWeight:700,verticalAlign:"bottom"}}>{grandTotalPrev||""}</td>
                  <td className="body-c" style={{verticalAlign:"bottom"}}></td>
                  <td className="body-c" style={{fontWeight:700,verticalAlign:"bottom"}}>{grandTotalPrev||""}</td>
                  <td style={{border:"none"}}></td>
                </tr>
                </tbody>
              </table>
            </div>

            {/* Party email */}
            <div style={{marginTop:12,display:"flex",alignItems:"center",gap:8}}>
              <span style={{fontSize:11,fontWeight:700,color:C.mid,whiteSpace:"nowrap"}}>Party Email ✉</span>
              <input value={edit.partyEmail||""} onChange={e=>setEdit(f=>({...f,partyEmail:e.target.value}))}
                placeholder="party@email.com"
                style={{flex:1,border:`1px solid ${C.border}`,borderRadius:5,padding:"6px 9px",fontSize:12,fontFamily:sans,outline:"none"}}/>
            </div>
            <p style={{margin:"6px 0 0",fontSize:10,color:C.light}}>💡 Click any cell to edit — product name, shape, quantities, case. ✕ to delete a row. Total &amp; G.TOTAL update automatically.</p>
          </div>

          {/* Actions */}
          <div style={{background:C.card,borderRadius:10,border:`1px solid ${C.border}`,padding:14,boxShadow:C.shadow,display:"flex",gap:8,flexWrap:"wrap",alignItems:"center"}}>
            <button className="btn" style={{background:"#EEE",color:C.dark}} onClick={()=>setStep("upload")}>← Back</button>
            <button className="btn" style={{background:"#2C3E50",color:"#fff"}} onClick={downloadPdf}>⬇ Download PDF</button>
            <button className="btn" style={{background:C.green,color:"#fff"}} onClick={sendEmail} disabled={!edit.partyEmail}>📧 Send to Party</button>
            {!edit.partyEmail&&<span style={{fontSize:11,color:C.red}}>Add party email to send</span>}
          </div>
        </>}

        {/* SENDING */}
        {step==="sending"&&(
          <div style={{background:C.card,borderRadius:10,border:`1px solid ${C.border}`,padding:48,textAlign:"center",boxShadow:C.shadow}}>
            <div className="spin"/>
            <h2 style={{fontFamily:serif,fontSize:17,color:C.dark,margin:"0 0 6px"}}>Sending…</h2>
            <p style={{color:C.light,fontSize:12,margin:0}}>Attaching PDF and sending to {edit.partyEmail}</p>
          </div>
        )}

        {/* DONE */}
        {step==="done"&&(
          <div style={{background:C.card,borderRadius:10,border:`2px solid ${C.green}`,padding:40,textAlign:"center",boxShadow:C.shadow}}>
            <div style={{fontSize:48,marginBottom:10}}>✅</div>
            <h2 style={{fontFamily:serif,fontSize:19,color:C.green,margin:"0 0 5px"}}>Order Sent!</h2>
            <p style={{color:C.mid,fontSize:13,margin:"0 0 18px"}}>{emailStatus}</p>
            <div style={{display:"flex",gap:8,justifyContent:"center",flexWrap:"wrap"}}>
              <button className="btn" style={{background:"#2C3E50",color:"#fff"}} onClick={downloadPdf}>⬇ Download PDF</button>
              <button className="btn" style={{background:YELLOW_CSS,color:C.dark}} onClick={reset}>📷 Scan Another</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
